# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'gif.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        self.graphicsView = QtWidgets.QGraphicsView(Dialog)
        self.graphicsView.setGeometry(QtCore.QRect(0, 0, 411, 301))
        self.graphicsView.setStyleSheet("background-image: url(:/gif/Downloads/giphy.gif);")
        self.graphicsView.setObjectName("graphicsView")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
import gif_source

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    gif = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(gif)
    
    gif.show()
    sys.exit(app.exec_())
