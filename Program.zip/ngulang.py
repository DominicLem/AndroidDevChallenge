from PyQt5 import QtGui, QtCore,QtWidgets
import ex

class fbrow(ex.Ui_MainWindow, QtWidgets.QMainWindow):
    def __init__(self):
        super (fbrow,self).__init__()
        self.setupUi(self)
        self.populate()
        
    def populate(self):
        path = "A:\Materi\Materi Cawu 3\Periode 2\Artificial Intelligence\Project\Voice-Authentication-and-Face-Recognition-master\gmm_models"
        model = QtWidgets.QFileSystemModel()
        model.setRootPath((QtCore.QDir.rootPath()))
        self.treeView.setModel(model)
        self.treeView.setRootIndex(model.index(path))
if __name__ =='__main__':
    app = QtWidgets.QApplication([])
    fb = fbrow()
    fb.show()
    app.exec_()