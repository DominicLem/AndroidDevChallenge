# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 08:21:00 2019

@author: banta
"""

import kivy